package http

/*
type Client struct {
}
*/
