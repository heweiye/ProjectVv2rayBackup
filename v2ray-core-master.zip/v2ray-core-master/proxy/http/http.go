package http

//go:generate errorgen
