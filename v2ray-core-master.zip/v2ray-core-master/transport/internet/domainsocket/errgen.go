package domainsocket

//go:generate errorgen
