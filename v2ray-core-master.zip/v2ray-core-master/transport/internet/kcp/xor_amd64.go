package kcp

func xorfwd(x []byte)
func xorbkd(x []byte)
