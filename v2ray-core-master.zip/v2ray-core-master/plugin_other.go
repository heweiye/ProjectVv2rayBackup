// +build !linux

package core

func loadPluginsInternal() error {
	return nil
}
