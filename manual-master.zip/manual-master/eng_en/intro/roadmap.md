# 开发计划

## 版本号

V2Ray Core 的版本号形如 X.Y.Z，其中 X 表示 Milestone，Y 表示 Release，如 2.3 表示第二个 Milestone 的第三个 Release；Z 表示测试版本。

## 周期

V2Ray Core 每周发布一个 [Release](https://github.com/v2ray/v2ray-core/releases)。从 2.0 开始，每个 Milestone 持续一年。

## 进度管理

所有新功能的讨论和计划都放在 [v2ray/Planning](https://github.com/v2ray/planning)。
