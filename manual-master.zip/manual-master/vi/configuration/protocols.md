---
refcn: chapter_02/02_protocols
refen: configuration/protocols
---
# Giao thức

V2Ray hỗ trợ các giao thức sau. Mỗi giao thức có thể là giao thức gửi đến hoặc giao thức gửi đi hoặc cả hai.

* [Hố đen](protocols/blackhole.md)
* [Cửa Dokodemo](protocols/dokodemo.md)
* [Sự tự do](protocols/freedom.md)
* [HTTP](protocols/http.md)
* [MTProto](protocols/mtproto.md)
* [Shadowsocks](protocols/shadowsocks.md)
* [Socks](protocols/socks.md)
* [VMess](protocols/vmess.md)