---
refcn: ui_client/index
refen: ui_client/index
---
# Project V Clients

Bên cạnh V2ray lõi, Project V bao gồm nhiều ứng dụng khách GUI khác nhau trên nhiều nền tảng. Vui lòng xem danh sách sau đây để ủng hộ bạn.

* [các cửa sổ](windows.md)
* [Mac OS X](osx.md)
* [iOS](ios.md)
* [Android](android.md)
* [Dịch vụ trực tuyến](ui_client/service.md)