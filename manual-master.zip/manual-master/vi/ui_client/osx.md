---
refcn: ui_client/osx
refen: ui_client/osx
---
# Mac OS X

## V2RayX

* Tải xuống: [Github](https://github.com/Cenmrev/V2RayX)

## Các công cụ khác {#other}

### Visual Studio Code

Trình chỉnh sửa mã nguồn từ Microsoft.

* Trang web: [code.visualstudio.com](https://code.visualstudio.com/)

### Telegram

Thảo luận được mã hóa.

* Trang web: [telegram.org](https://telegram.org/)
* Tải xuống: [Mac App Store](https://www.v2ray.com/itunesm/us/telegram-desktop/id946399090/)

### Ứng dụng khách Microsoft Remote Desktop Connection

* Tải xuống: [Mac App Store](https://www.v2ray.com/itunesm/us/microsoft-remote-desktop/id715768417/)