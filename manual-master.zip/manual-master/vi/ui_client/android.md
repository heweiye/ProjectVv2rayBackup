---
refcn: ui_client/android
refen: ui_client/android
---
# Ứng dụng khách Android

## BifrostV

BifrostV là một ứng dụng Android dựa trên lõi V2Ray. Nó hỗ trợ VMess, Shadowsocks, giao thức vớ.

* Tải xuống: [Cửa hàng Play](https://play.google.com/store/apps/details?id=com.github.dawndiy.bifrostv)
* Tải xuống: [APK thuần túy](https://apkpure.com/bifrostv/com.github.dawndiy.bifrostv)

## V2RayNG

V2RayNG là một ứng dụng Android dựa trên V2Ray. Nó cung cấp cùng một tính năng được đặt làm lõi V2Ray.

* Tải xuống: [Cửa hàng Play](https://play.google.com/store/apps/details?id=com.v2ray.ang)
* Nguồn: [GitHub](https://github.com/2dust/v2rayNG)

## V2Ray Go

* Tải xuống: [Cửa hàng Play](https://play.google.com/store/apps/details?id=org.kkdev.v2raygo)
* Nguồn: [Github](https://github.com/xiaokangwang/V2RayGO)

## Actinium

* Tải xuống: Cửa hàng Play (Không khả dụng)
* Nguồn: [Github](https://github.com/V2Ray-Android/Actinium)

## Các công cụ khác {#other}

### JuiceSSH

SSH client.

* Tải xuống: [Cửa hàng Play](https://play.google.com/store/apps/details?id=com.sonelli.juicessh)
* Trang web: [JuiceSSH.com](https://juicessh.com/)

### Termius

Ứng dụng SSH

* Tải xuống: [Cửa hàng Play](https://play.google.com/store/apps/details?id=com.server.auditor.ssh.client)

### Telegram

Thảo luận được mã hóa.

* Trang web: [telegram.org](https://telegram.org/)
* Tải xuống: [Cửa hàng Play](https://play.google.com/store/apps/details?id=org.telegram.messenger)