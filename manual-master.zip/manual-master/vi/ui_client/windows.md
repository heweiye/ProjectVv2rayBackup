---
refcn: ui_client/windows
refen: ui_client/windows
---
# các cửa sổ

## V2RayW

* Tải xuống: [Github](https://github.com/Cenmrev/V2RayW)

## V2RayN

* Tải xuống: [Github](https://github.com/2dust/v2rayN)

## V2RayS

* Tải xuống: [Github](https://github.com/Shinlor/V2RayS)

## Các công cụ khác {#other}

### PuTTY

SSH client.

* Trang web: [putty.org](http://www.putty.org/)

### Visual Studio Code

Trình chỉnh sửa mã nguồn từ Microsoft.

* Trang web: [code.visualstudio.com](https://code.visualstudio.com/)

### Telegram

Thảo luận được mã hóa.

* Trang web: [telegram.org](https://telegram.org/)