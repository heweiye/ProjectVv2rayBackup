---
refcn: ui_client/osx
refen: ui_client/osx
---

# Mac OS X

## V2RayX

* Download: [Github](https://github.com/Cenmrev/V2RayX)

## Other tools {#other}

### Visual Studio Code

Source code editor from Microsoft.

* Website: [code.visualstudio.com](https://code.visualstudio.com/)

### Telegram

Encrypted discussion.

* Website: [telegram.org](https://telegram.org/)
* Download: [Mac App Store](https://www.v2ray.com/itunesm/us/telegram-desktop/id946399090/)

### Microsoft Remote Desktop Connection Client

* Download: [Mac App Store](https://www.v2ray.com/itunesm/us/microsoft-remote-desktop/id715768417/)
