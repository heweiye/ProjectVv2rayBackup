---
refcn: ui_client/windows
refen: ui_client/windows
---

# Windows

## V2RayW

* Download: [Github](https://github.com/Cenmrev/V2RayW)

## V2RayN

* Download: [Github](https://github.com/2dust/v2rayN)

## V2RayS

* Download: [Github](https://github.com/Shinlor/V2RayS)

## Other tools {#other}

### PuTTY

SSH client.

* Website: [putty.org](http://www.putty.org/)

### Visual Studio Code

Source code editor from Microsoft.

* Website: [code.visualstudio.com](https://code.visualstudio.com/)

### Telegram

Encrypted discussion.

* Website: [telegram.org](https://telegram.org/)
