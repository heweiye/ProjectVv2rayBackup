---
refcn: ui_client/index
refen: ui_client/index
---
# Клиенты Project V

Кроме ядра V2ray, Project V включает в себя различные графические клиенты на многих платформах. Обратите внимание на список ниже, в подкатегориях много полезного.

* [Windows](windows.md)
* [Mac OS X](osx.md)
* [iOS](ios.md)
* [Android](android.md)
* [Онлайн сервисы](ui_client/service.md)