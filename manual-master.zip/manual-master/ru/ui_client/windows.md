---
refcn: ui_client/windows
refen: ui_client/windows
---
# Windows

## V2RayW

* Загрузить: [GitHub](https://github.com/Cenmrev/V2RayW)

## V2RayN

* Загрузить: [GitHub](https://github.com/2dust/v2rayN)

## V2RayS

* Загрузить: [GitHub](https://github.com/Shinlor/V2RayS)

## Другие инструменты {#other}

### PuTTY

Клиент SSH.

* Веб-сайт: [putty.org](http://www.putty.org/)

### Visual Studio Code

Редактор исходного кода от Microsoft.

* Веб-сайт: [code.visualstudio.com](https://code.visualstudio.com/)

### Telegram

Зашифрованное общение.

* Веб-сайт: [telegram.org](https://telegram.org/)