---
refcn: ui_client/osx
refen: ui_client/osx
---
# Mac OS X

## V2RayX

* Загрузить: [GitHub](https://github.com/Cenmrev/V2RayX)

## Другие инструменты {#other}

### Visual Studio Code

Редактор исходного кода от Microsoft.

* Веб-сайт: [code.visualstudio.com](https://code.visualstudio.com/)

### Telegram

Зашифрованное общение.

* Веб-сайт: [telegram.org](https://telegram.org/)
* Загрузить: [Mac App Store](https://www.v2ray.com/itunesm/us/telegram-desktop/id946399090/)

### Клиент подключения к удаленному рабочему столу от Microsoft

* Загрузить: [Mac App Store](https://www.v2ray.com/itunesm/us/microsoft-remote-desktop/id715768417/)