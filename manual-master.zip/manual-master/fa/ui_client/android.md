---
refcn: ui_client/android
refen: ui_client/android
---
# مشتری Android

## BifrostV

BifrostV یک برنامه آندروید بر اساس هسته V2Ray است. از VMess، Shadowsocks، پروتکل های جوراب پشتیبانی می کند.

* دانلود: [فروشگاه بازی](https://play.google.com/store/apps/details?id=com.github.dawndiy.bifrostv)
* دانلود: [APK خالص](https://apkpure.com/bifrostv/com.github.dawndiy.bifrostv)

## V2RayNG

V2RayNG نرم افزار آندروید بر اساس V2Ray است. این ویژگی همان ویژگی را به عنوان هسته V2Ray فراهم می کند.

* دانلود: [فروشگاه بازی](https://play.google.com/store/apps/details?id=com.v2ray.ang)
* منبع: [GitHub](https://github.com/2dust/v2rayNG)

## V2Ray برو

* دانلود: [فروشگاه بازی](https://play.google.com/store/apps/details?id=org.kkdev.v2raygo)
* منبع: [Github](https://github.com/xiaokangwang/V2RayGO)

## اکتینیم

* دانلود: بازی فروشگاه (در دسترس نیست)
* منبع: [Github](https://github.com/V2Ray-Android/Actinium)

## ابزارهای دیگر {#other}

### JuiceSSH

مشتری SSH

* دانلود: [فروشگاه بازی](https://play.google.com/store/apps/details?id=com.sonelli.juicessh)
* وب سایت: [JuiceSSH.com](https://juicessh.com/)

### ترموس

مشتری SSH

* دانلود: [فروشگاه بازی](https://play.google.com/store/apps/details?id=com.server.auditor.ssh.client)

### تلگرام

بحث رمزگذاری شده

* وب سایت: [telegram.org](https://telegram.org/)
* دانلود: [فروشگاه بازی](https://play.google.com/store/apps/details?id=org.telegram.messenger)