---
refcn: ui_client/ios
refen: ui_client/ios
---
# مشتری iOS

## Kitsunebi

Kitsunebi یک برنامه iOS مبتنی بر V2Ray است. این قابلیت کامل به عنوان V2Ray را فراهم می کند. همچنین از وارد کردن و صادرات پیکربندی JSON سازگار با V2Ray پشتیبانی می کند.

* دانلود: iTunes (در دسترس نیست)

## Kitsunebi Lite

نسخه سبک Kitsunebi.

* دانلود: [iTunes](https://www.v2ray.com/itunes/us/kitsunebi-lite/id1387913765/)

## Shadowrocket

Shadowrocket یک برنامه VPN عمومی است. پشتیبانی از چندین پروتکل مانند Shadowsocks، VMess، SSR و غیره

* دانلود: [iTunes](https://www.v2ray.com/itunes/us/shadowrocket/id932747118/)

## Pepi (ShadowRay بود) {#pepi}

Pepi برنامه V2Ray سازگار است. آیا قادر است اتصال VPN را بر اساس پروتکل VMess برقرار کند و با هر سرور V2Ray ارتباط برقرار کند.

* دانلود: [iTunes](https://www.v2ray.com/itunes/us/pepi/id1283082051/)

## کوانتومی

* دانلود: [iTunes](https://www.v2ray.com/itunes/us/quantumult/id1252015438/)

## ابزارهای دیگر {#other}

### HyperApp

یک ابزار برای ساخت سرور با docker.

* دانلود: [iTunes](https://www.v2ray.com/itunes/us/hyperapp/id1179750280/)
* وب سایت: [HyperApp.fun](https://www.hyperapp.fun/)

### ترموس

مشتری SSH

* دانلود: [iTunes](https://www.v2ray.com/itunes/us/termius/id549039908/)

### تلگرام

بحث رمزگذاری شده

* وب سایت: [telegram.org](https://telegram.org/)
* دانلود: [iTunes](https://www.v2ray.com/itunes/us/telegram-messenger/id686449807/)

### ProtonMail

ایمیل رمزگذاری شده

* وب سایت: [protonmail.com](https://protonmail.com/)
* دانلود: [iTunes](https://www.v2ray.com/itunes/us/protonmail-encrypted-email/id979659905/)