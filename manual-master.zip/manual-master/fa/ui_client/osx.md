---
refcn: ui_client/osx
refen: ui_client/osx
---
# Mac OS X

## V2RayX

* دانلود: [Github](https://github.com/Cenmrev/V2RayX)

## ابزارهای دیگر {#other}

### ویژوال استودیو کد

ویرایشگر کد منبع از مایکروسافت.

* وب سایت: [code.visualstudio.com](https://code.visualstudio.com/)

### تلگرام

بحث رمزگذاری شده

* وب سایت: [telegram.org](https://telegram.org/)
* دانلود: [فروشگاه مک فروشگاه](https://www.v2ray.com/itunesm/us/telegram-desktop/id946399090/)

### مشتری Microsoft Remote Desktop Connection

* دانلود: [فروشگاه مک فروشگاه](https://www.v2ray.com/itunesm/us/microsoft-remote-desktop/id715768417/)