---
refcn: ui_client/index
refen: ui_client/index
---
# مشتریان پروژه V

علاوه بر هسته V2ray، پروژه V شامل انواع مختلفی از مشتریان GUI در بسیاری از سیستم عامل ها می باشد. لطفا لیست زیر را برای نفع خود ببینید.

* [پنجره ها](windows.md)
* [Mac OS X](osx.md)
* [در iOS](ios.md)
* [اندروید](android.md)
* [خدمات آنلاین](ui_client/service.md)