---
refcn: ui_client/service
refen: ui_client/service
---
# خدمات آنلاین

## V2Ray مرتبط است

* [ژنراتور پیکربندی](https://htfy96.github.io/v2ray-config-gen/)
* [ژنراتور UUID](https://www.uuidgenerator.net/)

## VPN

* [BabyDriver](http://babydriver.me/): پشتیبانی از V2Ray. کد کوپن: bcb518
* [喵 帕斯](https://xn--i2ru8q2qg.com/): حمایت V2Ray (بتا)
* [Lanan](https://xn--sjt174g.com/): سرویس VPN مبتنی بر V2Ray. کد کوپن: v2ray
* [多数 派](https://dspi.io/aff.php?aff=7): سرویس VPN جدید مبتنی بر V2Ray.
* [V2rayPro](https://myv2.us): سرویس VPN بر اساس V2Ray. کد کوپن: v2ray.com

## دامنه ها

* [بیایید رمزگذاری](https://letsencrypt.org/): گواهینامه TLS رایگان

## VPS

* [ولتر](https://www.vultr.com/?ref=7269307)
* [BlueHost](https://www.bluehost.com/track/v2ray/)

## Cryptocurrency

* [LocalBitcoins](https://localbitcoins.com/?ch=khtm): Trade Bitcoins offline
* [CoinCola](https://www.coincola.com/mobile/signup?ref=QAcvfy2g): بازار OTC برای تجارت BTC، ETH، BCH، USDT.
* [Binance](https://www.binance.com/?ref=35382451): بازار معاملاتی برای ارزهای رمزنگاری.
* [Coinex](https://www.coinex.com/account/signup?refer_code=r3fmp): بازار معاملاتی برای ارزهای رمزنگاری.
* [CoinPayment](https://www.coinpayments.net/index.php?ref=abc5f542afed6b37b4b3d7fb83242d18): Online crypto currency wallet

## شانست را امتحان کن

* [PrimeDice](https://primedice.com/?c=default): Dice game with bitcoin.
* [OneHash](https://www.onehash.com/?ap=56d52158f7e04b169ec54d): شرط بندی های ورزشی با Bitcoin، از جمله جام جهانی 2018.
* [Bitsler](https://www.bitsler.com/?ref=VictoriaR): بازی های کازینو با Bitcoin.