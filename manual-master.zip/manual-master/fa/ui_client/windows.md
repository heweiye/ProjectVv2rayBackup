---
refcn: ui_client/windows
refen: ui_client/windows
---
# پنجره ها

## V2RayW

* دانلود: [Github](https://github.com/Cenmrev/V2RayW)

## V2RayN

* دانلود: [Github](https://github.com/2dust/v2rayN)

## V2RayS

* دانلود: [Github](https://github.com/Shinlor/V2RayS)

## ابزارهای دیگر {#other}

### پوتای

مشتری SSH

* وب سایت: [بطری](http://www.putty.org/)

### ویژوال استودیو کد

ویرایشگر کد منبع از مایکروسافت.

* وب سایت: [code.visualstudio.com](https://code.visualstudio.com/)

### تلگرام

بحث رمزگذاری شده

* وب سایت: [telegram.org](https://telegram.org/)