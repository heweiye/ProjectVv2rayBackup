---
refcn: chapter_02/02_protocols
refen: configuration/protocols
---
# پروتکل ها

V2Ray از پروتکل های زیر پشتیبانی می کند. هر پروتکل ممکن است یک پروتکل ورودی یا یک پروتکل خروجی یا هر دو باشد.

* [سیاه چاله](protocols/blackhole.md)
* [Dokodemo درب](protocols/dokodemo.md)
* [آزادی](protocols/freedom.md)
* [HTTP](protocols/http.md)
* [MTProto](protocols/mtproto.md)
* [Shadowsocks](protocols/shadowsocks.md)
* [Socks](protocols/socks.md)
* [VMess](protocols/vmess.md)