# V2Ray.com

This is the source code for building [v2ray.com](https://www.v2ray.com/).

The code is written as [Gitbook](https://www.gitbook.com/) format, and deployed by project admin.

## License

This work is licensed under a [Creative Commons Attribution 4.0 International License](https://creativecommons.org/licenses/by/4.0/).
