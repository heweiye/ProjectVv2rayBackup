---
refcn: chapter_02/02_protocols
refen: configuration/protocols
---
# 프로토콜

V2Ray는 다음 프로토콜을 지원합니다. 각 프로토콜은 인바운드 프로토콜이거나 아웃 바운드 프로토콜이거나 둘 다일 수 있습니다.

* [블랙홀](protocols/blackhole.md)
* [도코 데모 문](protocols/dokodemo.md)
* [자유](protocols/freedom.md)
* [HTTP](protocols/http.md)
* [MTProto](protocols/mtproto.md)
* [Shadowsocks](protocols/shadowsocks.md)
* [Socks](protocols/socks.md)
* [VMess](protocols/vmess.md)