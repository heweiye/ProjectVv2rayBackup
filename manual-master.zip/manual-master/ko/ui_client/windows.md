---
refcn: ui_client/windows
refen: ui_client/windows
---
# Windows

## V2RayW

* 다운로드 : [Github](https://github.com/Cenmrev/V2RayW)

## V2RayN

* 다운로드 : [Github](https://github.com/2dust/v2rayN)

## V2RayS

* 다운로드 : [Github](https://github.com/Shinlor/V2RayS)

## 기타 도구 {#other}

### 퍼티

SSH 클라이언트.

* 웹 사이트 : [putty.org](http://www.putty.org/)

### Visual Studio 코드

Microsoft의 소스 코드 편집기.

* 웹 사이트 : [code.visualstudio.com](https://code.visualstudio.com/)

### 전보

암호화 된 토론.

* 웹 사이트 : [telegram.org](https://telegram.org/)