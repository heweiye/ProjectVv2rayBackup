---
refcn: ui_client/osx
refen: ui_client/osx
---
# 맥 OS X

## V2RayX

* 다운로드 : [Github](https://github.com/Cenmrev/V2RayX)

## 기타 도구 {#other}

### Visual Studio 코드

Microsoft의 소스 코드 편집기.

* 웹 사이트 : [code.visualstudio.com](https://code.visualstudio.com/)

### 전보

암호화 된 토론.

* 웹 사이트 : [telegram.org](https://telegram.org/)
* 다운로드 : [Mac App Store](https://www.v2ray.com/itunesm/us/telegram-desktop/id946399090/)

### Microsoft 원격 데스크톱 연결 클라이언트

* 다운로드 : [Mac App Store](https://www.v2ray.com/itunesm/us/microsoft-remote-desktop/id715768417/)