---
refcn: ui_client/index
refen: ui_client/index
---
# 프로젝트 V 클라이언트

핵심 V2ray 외에, Project V는 많은 플랫폼에 다양한 GUI 클라이언트를 포함합니다. 다음 목록을 참조하십시오.

* [Windows](windows.md)
* [맥 OS X](osx.md)
* [iOS](ios.md)
* [기계적 인조 인간](android.md)
* [온라인 서비스](ui_client/service.md)