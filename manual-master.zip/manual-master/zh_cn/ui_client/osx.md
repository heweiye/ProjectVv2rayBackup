---
refcn: ui_client/osx
refen: ui_client/osx
---

# Mac OS X

## V2RayX

V2RayX 是一个基于 V2Ray 内核的 Mac OS X 客户端。用户可以通过界面生成配置文件，并且可以手动更新 V2Ray 内核。V2RayX 还可以配置系统代理。

* 下载：[Github](https://github.com/Cenmrev/V2RayX)

## 其它工具 {#others}

### Visual Studio Code

微软出品的一款轻量级代码编辑工具。

* 官网：[code.visualstudio.com](https://code.visualstudio.com/)

### Telegram

加密聊天神器。

* 官网：[telegram.org](https://telegram.org/)
* 下载：[Mac App Store](https://www.v2ray.com/itunesm/us/telegram-desktop/id946399090/)

### Microsoft Remote Desktop Connection Client

Windows 远程桌面客户端

* 下载：[Mac App Store](https://www.v2ray.com/itunesm/us/microsoft-remote-desktop/id715768417/)
