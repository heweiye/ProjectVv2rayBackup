---
refcn: ui_client/windows
refen: ui_client/windows
---

# Windows 客户端

## V2RayW

V2RayW 是一个基于 V2Ray 内核的 Windows 客户端。用户可以通过界面生成配置文件，并且可以手动更新 V2Ray 内核。

* 下载：[Github](https://github.com/Cenmrev/V2RayW)

## V2RayN

V2RayN 是一个基于 V2Ray 内核的 Windows 客户端。

* 下载：[Github](https://github.com/2dust/v2rayN)

## V2RayS

* 下载：[Github](https://github.com/Shinlor/V2RayS)

## V2RayGCon

* 下载：[Github](https://github.com/nobody3u/V2RayGCon)

## 其它工具 {#others}

### PuTTY

SSH 客户端

* 官网：[putty.org](http://www.putty.org/)

### Visual Studio Code

微软出品的一款轻量级代码编辑工具。

* 官网：[code.visualstudio.com](https://code.visualstudio.com/)

### Telegram

加密聊天神器。

* 官网：[telegram.org](https://telegram.org/)
