---
refcn: chapter_02/02_protocols
refen: configuration/protocols
---

# V2Ray 协议列表

V2Ray 支持以下协议：

* [Blackhole](protocols/blackhole.md)
* [Dokodemo-door](protocols/dokodemo.md)
* [Freedom](protocols/freedom.md)
* [HTTP](protocols/http.md)
* [MTProto](protocols/mtproto.md)
* [Shadowsocks](protocols/shadowsocks.md)
* [Socks](protocols/socks.md)
* [VMess](protocols/vmess.md)
